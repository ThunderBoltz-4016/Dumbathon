'use client';
import { useState, useEffect, useRef, useCallback } from 'react';
import { CAPTCHA_POOL, type CaptchaChallenge } from '@/data/products';
import { TRICK_QUESTIONS, type TrickQuestion } from '@/data/trickQuestions';

interface CaptchaOverlayProps {
  onPass: () => void;
}

type ChallengeMode = 'classic' | 'trick';

export default function CaptchaOverlay({ onPass }: CaptchaOverlayProps) {
  const [mode, setMode] = useState<ChallengeMode>('classic');
  const [challenge, setChallenge] = useState<CaptchaChallenge | null>(null);
  const [trickQ, setTrickQ] = useState<TrickQuestion | null>(null);
  const [selected, setSelected] = useState<number[]>([]);
  const [chosenOption, setChosenOption] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [explanation, setExplanation] = useState('');
  const [countdown, setCountdown] = useState(15);
  const [clickCount, setClickCount] = useState(0);
  const [invisPos] = useState({ x: Math.random() * 70 + 10, y: Math.random() * 60 + 20 });
  const [attempt, setAttempt] = useState(0);
  const [shaking, setShaking] = useState(false);
  const [showExplanation, setShowExplanation] = useState(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const movedRef = useRef(false);

  const CATEGORY_LABELS: Record<string, string> = {
    math: '🔢 MATH TRAP',
    wordplay: '🎭 WORDPLAY TRAP',
    logic: '🧠 LOGIC TRAP',
    spelling: '✏️ SPELLING TRAP',
    emoji: '😈 EMOJI TRAP',
    apocalypse: '☢️ APOCALYPSE PROTOCOL',
  };

  const pickChallenge = useCallback(() => {
    setError('');
    setExplanation('');
    setShowExplanation(false);
    setSelected([]);
    setChosenOption(null);
    setClickCount(0);
    movedRef.current = false;
    setCountdown(15);
    if (timerRef.current) clearInterval(timerRef.current);

    const useTrick = Math.random() > 0.4;
    if (useTrick) {
      const q = TRICK_QUESTIONS[Math.floor(Math.random() * TRICK_QUESTIONS.length)];
      setTrickQ(q);
      setChallenge(null);
      setMode('trick');
    } else {
      const c = CAPTCHA_POOL[Math.floor(Math.random() * CAPTCHA_POOL.length)];
      setChallenge(c);
      setTrickQ(null);
      setMode('classic');
    }
  }, []);

  useEffect(() => { pickChallenge(); }, [pickChallenge]);

  useEffect(() => {
    if (mode !== 'classic' || challenge?.type !== 'countdown') return;
    timerRef.current = setInterval(() => {
      if (movedRef.current) {
        setCountdown(15);
        movedRef.current = false;
        setError('YOU TWITCHED. Timer reset. The market sees all.');
      } else {
        setCountdown(prev => {
          if (prev <= 1) { clearInterval(timerRef.current!); onPass(); return 0; }
          return prev - 1;
        });
      }
    }, 1000);
    return () => clearInterval(timerRef.current!);
  }, [challenge, mode, onPass]);

  const triggerWrong = (msg: string, exp?: string) => {
    setError(msg);
    if (exp) { setExplanation(exp); setShowExplanation(true); }
    setShaking(true);
    setTimeout(() => setShaking(false), 600);
    setAttempt(a => a + 1);
    setTimeout(pickChallenge, exp ? 3800 : 2000);
  };

  const handleTrickOption = (opt: string) => {
    if (showExplanation) return;
    setChosenOption(opt);
    if (opt.toLowerCase().trim() === trickQ!.answer.toLowerCase().trim()) {
      setTimeout(onPass, 500);
    } else {
      triggerWrong(`❌ WRONG. You chose "${opt}".`, trickQ!.explanation);
    }
  };

  const handleGridClick = (idx: number) => {
    setSelected(prev => prev.includes(idx) ? prev.filter(i => i !== idx) : [...prev, idx]);
  };

  const handleClassicVerify = () => {
    if (!challenge) return;
    if (challenge.type === 'grid-select' || challenge.type === 'blank-grid') {
      const correct = (challenge.data?.correctIndices as number[]) || [];
      const ok = correct.length === selected.length && correct.every(i => selected.includes(i));
      if (ok) { onPass(); return; }
      triggerWrong(challenge.data?.note as string || '☠️ Wrong. Try again.');
      return;
    }
    if (challenge.type === 'click-count') {
      if (clickCount === (challenge.data?.target as number)) { onPass(); return; }
      triggerWrong(`You clicked ${clickCount}. Target: ${challenge.data?.target}. Reset.`);
      setClickCount(0);
    }
  };

  const handleOptionClick = (opt: string) => {
    if (!challenge) return;
    if (challenge.id === 'trolley-problem' && opt === 'Add all 6 to cart') { onPass(); return; }
    triggerWrong(`"${opt}" — The Market rejects this answer.`);
  };

  const handleCountClick = () => {
    const target = challenge?.data?.target as number || 50;
    const next = clickCount + 1;
    if (next > target) {
      setClickCount(0);
      setError(`${next} clicks — TOO MANY. Reset to 0.`);
    } else {
      setClickCount(next);
      if (next === target) onPass();
    }
  };

  const isTrick = mode === 'trick' && trickQ;
  const isClassic = mode === 'classic' && challenge;
  const accentColor = isTrick ? '#aaff00' : '#00ff41';

  return (
    <div
      className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/96"
      onMouseMove={() => { if (challenge?.type === 'countdown') movedRef.current = true; }}
    >
      <div className="absolute inset-0 flex items-center justify-center opacity-[0.03] text-[28rem] pointer-events-none select-none">☣️</div>

      <div
        className={`relative w-full max-w-lg mx-4 bg-[#060f06] border-2 overflow-hidden ${shaking ? 'animate-shake' : ''}`}
        style={{
          borderColor: accentColor,
          boxShadow: `0 0 50px ${accentColor}44, inset 0 0 50px rgba(0,0,0,0.9)`,
        }}
      >
        {/* Header */}
        <div className="px-5 py-4 border-b flex items-center justify-between"
          style={{ borderColor: `${accentColor}30`, background: isTrick ? '#111800' : '#001400' }}>
          <div className="flex items-center gap-3">
            <span className="text-2xl animate-pulse">{isTrick ? trickQ.emoji : '☣️'}</span>
            <div>
              <p className="text-[10px] tracking-[0.25em] font-mono opacity-50" style={{ color: accentColor }}>
                {isTrick ? `ZOMBIE BLACK MARKET — ${CATEGORY_LABELS[trickQ.category]}` : 'SECURITY CHECKPOINT — HUMANITY VERIFICATION'}
              </p>
              <h2 className="font-display text-2xl tracking-widest" style={{ color: accentColor }}>
                {isTrick ? 'RAGEBAIT INTELLIGENCE TEST' : "PROVE YOU'RE ALIVE"}
              </h2>
            </div>
          </div>
          <div className="text-right">
            <p className="text-xs font-mono opacity-30" style={{ color: accentColor }}>ATTEMPT</p>
            <p className="text-lg font-display opacity-50" style={{ color: accentColor }}>#{attempt + 1}</p>
          </div>
        </div>

        {/* Content */}
        <div className="p-6">

          {/* Question box */}
          <div className="border p-4 mb-5" style={{ borderColor: `${accentColor}25`, background: isTrick ? '#0d1400' : '#001200' }}>
            <p className="text-sm leading-relaxed font-mono whitespace-pre-line" style={{ color: isTrick ? '#ccff44' : '#a0ffb0' }}>
              {isTrick ? trickQ.question : challenge?.instruction}
            </p>
            {isClassic && challenge.data?.note && (
              <p className="text-[10px] mt-2 font-mono opacity-40" style={{ color: accentColor }}>
                {challenge.data.note as string}
              </p>
            )}
          </div>

          {/* TRICK OPTIONS */}
          {isTrick && (
            <div className="flex flex-col gap-2 mb-4">
              {trickQ.options.map((opt, i) => {
                const isChosen = chosenOption === opt;
                const isWrong = isChosen && showExplanation;
                return (
                  <button
                    key={i}
                    onClick={() => handleTrickOption(opt)}
                    disabled={showExplanation}
                    className="w-full border text-left px-4 py-3 text-sm font-mono transition-all disabled:cursor-not-allowed"
                    style={{
                      borderColor: isWrong ? '#8b0000' : isChosen ? accentColor : `${accentColor}25`,
                      background: isWrong ? 'rgba(139,0,0,0.15)' : isChosen ? `${accentColor}12` : '#0a1200',
                      color: isWrong ? '#ff6666' : isChosen ? accentColor : '#99ffaa',
                    }}
                  >
                    <span className="opacity-40 mr-3 font-display">{['A','B','C','D'][i]}.</span>
                    {opt}
                  </button>
                );
              })}
            </div>
          )}

          {/* CLASSIC CHALLENGES */}
          {isClassic && (
            <div className="mb-4 min-h-[180px] flex items-center justify-center">

              {(challenge.type === 'grid-select' || challenge.type === 'blank-grid') && (
                <div className="grid grid-cols-3 gap-1.5 w-full">
                  {Array.from({ length: 9 }).map((_, i) => (
                    <button key={i} onClick={() => handleGridClick(i)}
                      className="aspect-square border text-3xl flex items-center justify-center transition-all"
                      style={{
                        borderColor: selected.includes(i) ? '#00ff41' : '#00ff4120',
                        background: selected.includes(i) ? '#00ff4118' : '#001800',
                        transform: selected.includes(i) ? 'scale(0.94)' : 'scale(1)',
                      }}>
                      {challenge.type === 'blank-grid' ? '' : (challenge.data?.images as string[])?.[i]}
                    </button>
                  ))}
                </div>
              )}

              {challenge.type === 'only-wrong' && (
                <div className="flex flex-col gap-3 w-full">
                  {(challenge.data?.options as string[])?.map((opt, i) => (
                    <button key={i} onClick={() => handleOptionClick(opt)}
                      className="w-full border border-[#00ff41]/20 bg-[#001800] hover:bg-[#00ff41]/8 text-[#a0ffb0] text-sm p-3 text-left transition-all hover:border-[#00ff41]/60 font-mono">
                      ▸ {opt}
                    </button>
                  ))}
                </div>
              )}

              {challenge.type === 'invisible-button' && (
                <div className="relative w-full h-48">
                  <p className="text-[#00ff41]/25 text-xs text-center font-mono">The VERIFY button exists somewhere on this panel.</p>
                  <div className="absolute inset-0">
                    <button onClick={onPass} className="absolute opacity-0 w-20 h-10 cursor-default"
                      style={{ left: `${invisPos.x}%`, top: `${invisPos.y}%` }} />
                  </div>
                </div>
              )}

              {challenge.type === 'countdown' && (
                <div className="text-center w-full py-4">
                  <div className={`text-8xl font-display text-[#00ff41] ${countdown <= 5 ? 'animate-pulse' : ''}`}
                    style={{ textShadow: '0 0 30px #00ff41, 0 0 60px #00ff4155' }}>
                    {countdown}
                  </div>
                  <p className="text-[#00ff41]/50 text-xs mt-3 font-mono tracking-widest">DO. NOT. MOVE. YOUR. MOUSE.</p>
                  <p className="text-[#00ff41]/30 text-xs mt-1 font-mono">
                    {countdown > 10 ? '🟢 Holding...' : countdown > 5 ? '🟡 Almost...' : '🔴 ONE PIXEL AND IT\'S OVER'}
                  </p>
                </div>
              )}

              {challenge.type === 'click-count' && (
                <div className="text-center w-full py-2">
                  <div className="font-display mb-3" style={{ color: accentColor }}>
                    <span className="text-6xl">{clickCount}</span>
                    <span className="text-2xl opacity-40"> / {challenge.data?.target as number}</span>
                  </div>
                  <button onClick={handleCountClick}
                    className="border-2 px-10 py-4 text-lg font-display tracking-widest transition-all active:scale-95"
                    style={{ borderColor: accentColor, color: accentColor }}>
                    CLICK ME
                  </button>
                  <p className="text-xs mt-3 font-mono opacity-30" style={{ color: accentColor }}>
                    {(challenge.data?.target as number) - clickCount} to go • going over = back to 0
                  </p>
                </div>
              )}
            </div>
          )}

          {/* EXPLANATION BOX */}
          {showExplanation && explanation && (
            <div className="border border-[#aaff00]/25 bg-[#141a00] p-4 mb-4">
              <p className="text-[#aaff00]/60 text-[10px] tracking-[0.2em] font-mono mb-2">
                ☠ EXPLANATION (you clearly needed this):
              </p>
              <p className="text-[#ccff44] text-sm font-mono leading-relaxed">{explanation}</p>
              <div className="flex items-center gap-2 mt-3">
                <div className="h-px flex-1 bg-[#aaff00]/10" />
                <p className="text-[#aaff00]/30 text-[10px] font-mono">Loading next challenge in 3s...</p>
                <div className="h-px flex-1 bg-[#aaff00]/10" />
              </div>
            </div>
          )}

          {/* ERROR (non-explanation) */}
          {error && !showExplanation && (
            <div className="bg-[#150000] border border-red-900 p-3 mb-4 text-red-400 text-xs font-mono">
              {error}
            </div>
          )}

          {/* Verify button for classic grid/count */}
          {isClassic &&
            challenge.type !== 'countdown' &&
            challenge.type !== 'invisible-button' &&
            challenge.type !== 'only-wrong' && (
            <button onClick={handleClassicVerify}
              className="w-full border-2 bg-transparent font-display text-xl tracking-[0.3em] py-3 hover:opacity-90 transition-all active:scale-[0.98]"
              style={{ borderColor: accentColor, color: accentColor, boxShadow: `0 0 20px ${accentColor}22` }}>
              ☣️ VERIFY HUMANITY ☣️
            </button>
          )}

          <p className="text-xs text-center mt-4 font-mono opacity-[0.15]" style={{ color: accentColor }}>
            {isTrick
              ? "Think carefully. Or panic. Your call."
              : "Difficulty is intentional. Suffering is a feature, not a bug."}
          </p>
        </div>
      </div>

      <style jsx>{`
        @keyframes shake {
          0%,100% { transform: translateX(0) rotate(0deg); }
          15% { transform: translateX(-10px) rotate(-0.5deg); }
          30% { transform: translateX(10px) rotate(0.5deg); }
          45% { transform: translateX(-7px); }
          60% { transform: translateX(7px); }
          75% { transform: translateX(-3px); }
          90% { transform: translateX(3px); }
        }
        .animate-shake { animation: shake 0.55s ease-in-out; }
      `}</style>
    </div>
  );
}
